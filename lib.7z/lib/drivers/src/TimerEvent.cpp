#include "drivers/TimerEvent.h"
using namespace mbed;

TimerEvent::TimerEvent(const ticker_data_t *data){

}

void TimerEvent::irq(uint32_t id){
        
}

TimerEvent::~TimerEvent(){

}

//virtual void handler() = 0;
MBED_DEPRECATED_SINCE("mbed-os-6.0.0", "Pass a chrono time_point, not an integer microsecond count. For example use `last_chrono_time + 5ms` rather than `last_us_time + 5000`.")
void TimerEvent::insert(timestamp_t timestamp){

}

void TimerEvent::insert(std::chrono::microseconds rel_time){

}

MBED_DEPRECATED_SINCE("mbed-os-6.0.0", "Pass a chrono time_point, not an integer microsecond count. For example use `last_chrono_time + 5ms` rather than `last_us_time + 5000`.")
void TimerEvent::insert_absolute(us_timestamp_t timestamp){

}

void TimerEvent::insert_absolute(TickerDataClock::time_point timestamp){

}

void TimerEvent::remove(){
    
}