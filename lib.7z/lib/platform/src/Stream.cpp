#include "platform/Stream.h"
#include "stdarg.h"
#include "Arduino.h"
namespace mbed {
    
    int Stream::putc(int c)
    {

    }
    int Stream::puts(const char *s)
    {
        
    }
    int Stream::getc()
    {

    }
    char *Stream::gets(char *s, int size)
    {

    }
    int Stream::printf(const char *format, ...) 
    {
        char _buf[512];
        va_list args;
        va_start(args, format);
        vsnprintf(_buf, sizeof(_buf), format, args);
        va_end(args);
        Serial.println(_buf);
    }
    int Stream::scanf(const char *format, ...) 
    {

    }
    int Stream::vprintf(const char *format, std::va_list args) 
    {
        char _buf[512];
        vsnprintf(_buf, sizeof(_buf), format, args);
        Serial.println(_buf);
    }
    int Stream::vscanf(const char *format, std::va_list args) 
    {

    }
    int Stream::close() 
    {

    }
    ssize_t Stream::write(const void *buffer, size_t length){

    }
    ssize_t Stream::read(void *buffer, size_t length){

    }
    off_t Stream::seek(off_t offset, int whence){

    }
    off_t Stream::tell(){

    }
    void Stream::rewind(){

    }
     int Stream::isatty(){

     }
    int Stream::sync(){

    }
    off_t Stream::size(){

    }
}